import requests

port_number=10020

# VMS IP:
#10.215.63.132
#10.215.63.133
#10.215.63.134


# Define the endpoint URL
url = f"http://10.215.63.132:{port_number}/VoucherAdmin"  # Replace with your actual API URL

print(f"URL: {url}")
# Prompt the user to enter the file name
file_name = input("Enter the XML file name (including extension): ")

if file_name == "1":
    file_name = "1_get_voucher.xml"

if file_name == "2":
    file_name="2_get_task_info.xml"

if file_name == "3":
    file_name="3_load_batch.xml"

if file_name == "4":
    file_name="4_load_check.xml"

if file_name=="5":
    file_name="5_test.xml"
# Read the XML payload from the specified file
try:
    with open(file_name, "r", encoding="utf-8") as file:
        xml_payload = file.read()
except FileNotFoundError:
    print(f"Error: File '{file_name}' not found.")
    exit(1)

# Set the headers
headers = {
    "Content-Type": "text/xml",
    "Accept": "text/xml",
    "Authorization": "Basic dnNpcHVzZXI6RXJpYzg4MG5AMTIzNDU2",
    "User-Agent":"AIR/2.6/1.0",

}

# Send the POST request with debugging enabled
response = requests.post(url, data=xml_payload, headers=headers, verify=False)  # Set verify=True for production

# Debugging: Print request details
print("Request Headers:", response.request.headers)
print("Request Body:", response.request.body)

# Handle the response
if response.status_code == 200:
    print("Response received:")
    print(response.text)
else:
    print(f"Request failed with status code {response.status_code}")
    response_txt = bytes(response.text, 'utf-8')
    print("Response text:", response_txt)
