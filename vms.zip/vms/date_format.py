from datetime import datetime

def transform_to_iso8601(date_str):
    try:
        # Parse the input date string
        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        # Convert to dateTime.iso8601 format
        iso8601_date = date_obj.strftime("%Y%m%dT%H:%M:%S+0000")  # Adjust timezone as needed
        return iso8601_date
    except ValueError:
        return "Invalid date format. Expected yyyy-mm-dd."

# Example usage
date_input = str(input("Enter date to transform: "))
print(transform_to_iso8601(date_input))

