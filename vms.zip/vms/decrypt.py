from io import StringIO
import pgpy
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from io import StringIO
import sys

def load_pgp_private_key(file_path, passphrase=None):
    """
        param:stt PGP secret key file path
        passphrase:str if the private key is locked the 
                       passphrase is required to unlock the key
        return: private key object that can be used for decryption
    """
    def extract_and_convert(pgp_key):
        private_key = pgp_key._key.keymaterial
        # Extract RSA components
        modulus = private_key.n
        public_exponent = private_key.e
        private_exponent = private_key.d
        prime1 = private_key.p
        prime2 = private_key.q
        #Extract RSA key from PGP private key by construct new key with the same components
        return  RSA.construct((modulus, public_exponent, private_exponent, prime1, prime2))
    pgp_key = pgpy.PGPKey.from_file(file_path)[0]
    #Check if key is locked and unlock it using passphrase
    if pgp_key.is_protected:
       if not passphrase:
          raise ValueError("Passphrase must be provided to unlock protected key.") 
       with pgp_key.unlock(passphrase):
            # Check if the key is an RSA key
            return extract_and_convert(pgp_key)
       return extract_and_convert(pgp_key)

def decrypt(key_path,enc_file_path,dec_file_path,passphrase=None) -> StringIO:
    with open(enc_file_path,'rb') as source:
         with open(dec_file_path,'w') as destination:
             new_key = load_pgp_private_key(key_path, passphrase=passphrase)
             #Open encrypted file
             #Init new cipher with the extracted key
             cipher = PKCS1_v1_5.new(new_key)
             #Reading the file as 256 chunk each iteration
             #PKCS1_v1_5 encrypted cipher must be the size of the private key
             #which is 256 in our case.
             while True:
                   current = source.read(256)
                   if len(current):
                      res_dec = cipher.decrypt(current,None)
                      #Merge the output bytes
                      destination.write(res_dec.decode())
                   else:break
     #Decode the result bytes
    return dec_file_path


key_path="/data/salespoint/SalesPoint/SalesPoint-Ooredoo/sales_point_ooredoo/lp_e_reload_ooredoo/security/secrets/v-key.asc"
enc_file_path="/data/salespoint/api_test/vms/11_VOUCHER_BATCH_20241202_00001.LOADED"
dec_file_path="/data/salespoint/api_test/vms/11_VOUCHER_BATCH_20241202_00001.LOADED.decrypt"
passphrase="12345678"

print(f"============= Start Decrypting ===========")
res = decrypt(key_path,enc_file_path,dec_file_path,passphrase)
print(f"============={res=}============")





